//
//  AppDelegate.h
//  Test
//
//  Created by Carlos Thurber Boaventura on 03/20/14.
//  Copyright (c) 2014 Bit6. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : Bit6ApplicationManager <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
