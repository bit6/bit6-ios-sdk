//
//  MakeCallViewController.h
//  CallDemo
//
//  Created by Carlos Thurber Boaventura on 06/13/14.
//  Copyright (c) 2014 Bit6. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MakeCallViewController : UIViewController

@end
