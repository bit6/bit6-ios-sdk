//
//  MessagingViewController.h
//  Test
//
//  Created by Carlos Thurber Boaventura on 03/31/14.
//  Copyright (c) 2014 Bit6. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ConversationsViewController : UIViewController

@end
