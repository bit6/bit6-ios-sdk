//
//  Bit6PushNotificationCenter.h
//  Bit6
//
//  Created by Carlos Thurber Boaventura on 03/31/14.
//  Copyright (c) 2014 Bit6. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

/*! Bit6PushNotificationCenter is used to handle the remote notifications. */
@interface Bit6PushNotificationCenter : NSObject

/*! Gets the default Bit6PushNotificationCenter object.
 @return Default Bit6PushNotificationCenter object.
 */
+ (Bit6PushNotificationCenter *)sharedInstance;

/*! Should be called inside the -[UIApplicationDelegate application:didReceiveRemoteNotification:] implementation.
 @param userInfo A dictionary that contains information related to the remote notification, potentially including a badge number for the app icon, an alert sound, an alert message to display to the user, a notification identifier, and custom data. The provider originates it as a JSON-defined dictionary that iOS converts to an NSDictionary object; the dictionary may contain only property-list objects plus NSNull.
 @note If the ApplicationDelegate extends Bit6ApplicationManager this is done automaticaly.
 */
- (void) bit6RemoteNotificationReceived:(NSDictionary*)userInfo;

/*! Should be called inside the -[UIApplicationDelegate application:didReceiveRemoteNotification:fetchCompletionHandler:] implementation.
 @param userInfo A dictionary that contains information related to the remote notification, potentially including a badge number for the app icon, an alert sound, an alert message to display to the user, a notification identifier, and custom data. The provider originates it as a JSON-defined dictionary that iOS converts to an NSDictionary object; the dictionary may contain only property-list objects plus NSNull.
 @param completionHandler The block to execute when the download operation is complete. When calling this block, pass in the fetch result value that best describes the results of your download operation. You must call this handler and should do so as soon as possible.
 @note If the ApplicationDelegate extends Bit6ApplicationManager this is done automaticaly.
 */
- (void) bit6RemoteNotificationReceived:(NSDictionary *)userInfo fetchCompletionHandler:(void (^)(UIBackgroundFetchResult))completionHandler;

@end